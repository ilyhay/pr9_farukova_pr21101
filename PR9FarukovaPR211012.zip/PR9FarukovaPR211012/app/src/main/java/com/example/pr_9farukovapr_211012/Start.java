package com.example.pr_9farukovapr_211012;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.example.pr_9farukovapr_211012.R;

public class Start extends AppCompatActivity implements View.OnClickListener {

    ImageView d;
    ImageButton s;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        s = findViewById(R.id.but_arrow);
        s.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        Intent intent = new Intent(this, Steps.class);
        startActivity(intent);
    }
}