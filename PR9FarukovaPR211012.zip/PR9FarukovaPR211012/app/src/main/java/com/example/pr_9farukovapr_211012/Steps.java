package com.example.pr_9farukovapr_211012;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.pr_9farukovapr_211012.R;

public class Steps extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_steps);
    }
}